package Obser

type Obser interface {
	handleEvent([]string)
}
